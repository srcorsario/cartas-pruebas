// Cartas · Escáner de fotos — en Maps/TripAdvisor: recibe las fotos de escaner.js y las guarda en la extensión.
window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data || e.data.tipo !== 'FOTOS-CARTA-ESC' || !Array.isArray(e.data.fotos)) return;
    var nuevas = e.data.fotos;
    chrome.storage.local.get({ fotos: [] }, function (r) {
        var l = r.fotos || [], idx = {};
        l.forEach(function (x, i) { idx[x.u] = i; });
        nuevas.forEach(function (x) {
            if (!x || typeof x.u !== 'string' || !/^https:\/\//.test(x.u)) return;
            var t = typeof x.t === 'string' ? x.t.slice(0, 80) : '', de = typeof x.de === 'string' ? x.de.slice(0, 80) : '';
            if (x.u in idx) { var y = l[idx[x.u]]; if (t && !y.t) y.t = t; if (de && !y.de) y.de = de; }
            else { idx[x.u] = l.length; l.push({ u: x.u, t: t, de: de }); }
        });
        chrome.storage.local.set({ fotos: l.slice(-1500) });
    });
});
