// Cartas · Escáner de fotos — en el editor: le pasa las fotos guardadas (🖼️ Fotos de internet).
(function () {
    function enviar() {
        chrome.storage.local.get({ fotos: [] }, function (r) {
            if (r.fotos && r.fotos.length) window.postMessage({ tipo: 'FOTOS-CARTA', fotos: r.fotos }, location.origin);
        });
    }
    document.documentElement.dataset.escanerFotos = '1';
    try { document.documentElement.dataset.escanerFotosVersion = chrome.runtime.getManifest().version; } catch (e) { }
    enviar();
    chrome.storage.onChanged.addListener(function (c, area) { if (area === 'local' && c.fotos) enviar(); });
    window.addEventListener('message', function (e) {
        if (e.source !== window || !e.data) return;
        if (e.data.tipo === 'FOTOS-CARTA-VACIAR') chrome.storage.local.set({ fotos: [] });
        // Vaciar en un editor: quitar solo las fotos de los restaurantes de esa web (las de otras webs se quedan)
        if (e.data.tipo === 'FOTOS-CARTA-QUITAR' && Array.isArray(e.data.de)) {
            var de = e.data.de, sin = !!e.data.sinOrigen;
            chrome.storage.local.get({ fotos: [] }, function (r) {
                chrome.storage.local.set({ fotos: (r.fotos || []).filter(function (x) { return x.de ? de.indexOf(x.de) < 0 : !sin; }) });
            });
        }
    });
})();
