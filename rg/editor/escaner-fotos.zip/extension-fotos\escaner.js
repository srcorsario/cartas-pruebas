// Cartas · Escáner de fotos — GENERADO desde editores\acceso\subir-foto.js (función escaner). No editar a mano.
// Corre en Google Maps / TripAdvisor (mundo de la página): recoge las fotos y las pasa a puente-fuente.js.
function escaner(modoExt) {
    if (window.__fotosCarta) { window.__fotosCarta.mostrar(); return; }
    var L = [], V = {}, ui = {};
    function enviar() { clearTimeout(ui.te); ui.te = setTimeout(function () { try { window.postMessage({ tipo: 'FOTOS-CARTA-ESC', fotos: L.slice() }, '*'); } catch (x) { } }, 800); }
    var RX = /https:\/\/[a-z0-9.-]*(?:googleusercontent|ggpht)\.com\/[^"'\s\\)<>,\]}|!]+|https:\/\/(?:dynamic-media-cdn|media-cdn)\.tripadvisor\.com\/media\/[^"'\s\\)<>,\]}|!]+/g;
    function idG(u) { var m = u.match(/googleusercontent\.com\/([^=!?&#\s"')]+)/); return m ? m[1] : ''; }
    function k(u) { var id = idG(u); if (id) return 'g:' + id; var ta = String(u).match(/tripadvisor\.com\/media\/photo-[a-z](?:\/\d{3,})?\/([^?#]+)/); if (ta) return 'ta:' + ta[1]; return u.replace(/[?#].*$/, '').replace(/=[^\/=]*$/, '').replace(/\/photo-[a-z]\//, '/photo-?/'); }
    function origen() {
        var h = location.href, m;
        try { h = decodeURIComponent(h); } catch (x) { }
        if ((m = h.match(/\/maps\/place\/([^\/@?]+)/))) return m[1].replace(/\+/g, ' ').trim() + ' (Google Maps)';
        if ((m = h.match(/-d\d+-Reviews-([^.\/?#]+)/))) return m[1].split('-')[0].replace(/_/g, ' ').trim() + ' (TripAdvisor)';
        return String(document.title || location.hostname).split(/[-|–·]/)[0].trim().slice(0, 60);
    }
    function nombreDe(e) {
        for (var n = e, k2 = 0; n && n !== document.body && k2 < 6; n = n.parentElement, k2++) {
            var alt = k2 === 0 && n.getAttribute && n.getAttribute('alt');
            if (alt && alt.length > 2 && alt.length < 90 && !/^(foto|photo|imagen|image|picture)\b|\b(foto|photo) (de|of)\b/i.test(alt)) return alt.trim();
            var al = n.getAttribute && n.getAttribute('aria-label');
            if (al && al.length > 2 && al.length < 90 && !/^(foto|photo|imagen|image|v[ií]deo)\b/i.test(al)) return al.trim();
            if (n.querySelectorAll && n.querySelectorAll('img').length > 2) break;
            var tx = (n.innerText || '').split('\n').map(function (x) { return x.trim(); })
                .filter(function (x) { return x.length > 2 && x.length < 70 && !/^(popular|foto|photo|v[ií]deo|\d+(\s|$))/i.test(x); });
            if (tx.length) return tx[0];
        }
        return '';
    }
    function add(u, tit) {
        if (!u) return;
        u = String(u).replace(/&amp;/g, '&').trim();
        if (u.indexOf('//') === 0) u = 'https:' + u;
        if (!/^https:/.test(u)) return;
        var id = idG(u), t = /tripadvisor\.com\/media\//.test(u);
        if (!id && !t) return;
        if (id && !/^(p|gps-cs-s|grass-cs|geougc-cs|geougc|gps-proxy|proxy)\//.test(id)) return;
        if (t && (/avatar/i.test(u) || /\/photo-[a-z]\/[^?]*\.(png|gif|svg)/i.test(u))) return;
        if (t && /[?&]w=(\d+)/.test(u) && +RegExp.$1 < 100) return;
        var c = k(u);
        if (V[c]) { if (tit && !V[c].t) { V[c].t = tit; enviar(); } return; }
        V[c] = { u: u, de: origen() }; if (tit) V[c].t = tit;
        L.push(V[c]); pintar(); enviar();
    }
    function texto(t) {
        if (!t || typeof t !== 'string') return;
        if (t.length > 8e6) t = t.slice(0, 8e6);
        t = t.replace(/\\u003d/gi, '=').replace(/\\u0026/gi, '&').replace(/\\u002f/gi, '/').replace(/\\\//g, '/').replace(/%2F/gi, '/').replace(/%3D/gi, '=').replace(/%3A/gi, ':');
        (t.match(RX) || []).forEach(function (u) { add(u); });
    }
    function fondos(bg, tit) { (String(bg || '').match(/url\(["']?[^"')]+/g) || []).forEach(function (m) { add(m.replace(/^url\(["']?/, ''), tit); }); }
    function barrer() {
        texto(location.href);
        var els = document.querySelectorAll('img,source,[style*="url("],[role="img"],button,a,[data-src],[data-lazyurl],[data-srcset]');
        for (var i = 0; i < els.length; i++) {
            var e = els[i];
            var nom = '';
            var tom = function () { if (!nom) nom = nombreDe(e) || ' '; return nom.trim(); };
            if (e.tagName === 'IMG') { var su = e.currentSrc || e.src; if (/googleusercontent|tripadvisor/.test(su)) add(su, tom()); }
            ['srcset', 'data-srcset', 'data-src', 'data-lazyurl'].forEach(function (at) {
                var v = e.getAttribute(at);
                if (v && /googleusercontent|tripadvisor/.test(v)) v.split(',').forEach(function (s) { add(s.trim().split(' ')[0], tom()); });
            });
            if (e.style && e.style.backgroundImage) fondos(e.style.backgroundImage, e.style.backgroundImage.indexOf('http') >= 0 ? tom() : '');
            else if (e.tagName !== 'IMG' && els.length < 5000) { var cs = getComputedStyle(e).backgroundImage; if (cs && cs !== 'none') fondos(cs, /googleusercontent|tripadvisor/.test(cs) ? tom() : ''); }
        }
    }
    var f0 = window.fetch;
    if (f0) window.fetch = function () {
        var pr = f0.apply(this, arguments);
        pr.then(function (r) { try { var ct = r.headers.get('content-type') || ''; if (!/image|video|font|octet/.test(ct)) r.clone().text().then(texto, function () { }); } catch (x) { } }, function () { });
        return pr;
    };
    var s0 = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
        this.addEventListener('load', function () { try { if (!this.responseType || this.responseType === 'text') texto(this.responseText); } catch (x) { } });
        return s0.apply(this, arguments);
    };
    function arrancar() {
        texto(document.documentElement.innerHTML);
        document.querySelectorAll('script').forEach(function (sc) { texto(sc.textContent); });
        barrer();
        setInterval(barrer, 1500);
    }

    function caja() {
        var m = 0, best = null;
        document.querySelectorAll('div,section,ul').forEach(function (e) {
            if (e.scrollHeight - e.clientHeight < 200 || e.clientHeight < 150) return;
            var oy = getComputedStyle(e).overflowY;
            if (oy !== 'auto' && oy !== 'scroll') return;
            var r = e.getBoundingClientRect();
            if (r.width < 100 || r.bottom < 0 || r.top > innerHeight) return;
            var enc = document.elementFromPoint(Math.min(innerWidth - 1, Math.max(0, r.left + r.width / 2)), Math.min(innerHeight - 1, Math.max(0, r.top + Math.min(r.height, innerHeight) / 2)));
            if (!enc || !(e.contains(enc) || enc.contains(e))) return;
            var n = e.querySelectorAll('img,source,[style*="url("]').length;
            if (n > m) { m = n; best = e; }
        });
        return best || document.scrollingElement;
    }
    var bajando = false;
    function bajar() {
        if (bajando) { bajando = false; return; }
        var c = caja(), quieto = 0, alto = -1;
        bajando = true; pintar();
        (function paso() {
            if (!bajando) { pintar(); return; }
            c.scrollTop = c.scrollTop + c.clientHeight * 0.9;
            c.dispatchEvent(new Event('scroll'));
            setTimeout(function () {
                barrer();
                var fin = c.scrollTop + c.clientHeight >= c.scrollHeight - 5;
                if (fin && c.scrollHeight === alto) quieto++; else quieto = 0;
                alto = c.scrollHeight;
                if (quieto >= 4) { bajando = false; pintar(); return; }
                paso();
            }, 900);
        })();
    }
    function copiar() {
        var txt = 'FOTOS-CARTA:' + JSON.stringify(L);
        var conNombre = L.filter(function (x) { return x.t; }).length;
        var ok = function () { ui.msg.textContent = '✔ ' + L.length + ' copiadas (' + conNombre + ' con nombre). En el editor (📷 Fotos del plato) pulsa Ctrl+V.'; };
        var aMano = function () {
            var ta = document.createElement('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;opacity:0';
            document.body.appendChild(ta); ta.select(); var r = false;
            try { r = document.execCommand('copy'); } catch (x) { }
            ta.remove();
            if (r) ok(); else ui.msg.textContent = 'No se pudo copiar. Vuelve a pulsar Copiar.';
        };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(ok, aMano); else aMano();
    }
    function el(tag, css, txt, padre) { var x = document.createElement(tag); if (css) x.style.cssText = css; if (txt) x.textContent = txt; if (padre) padre.appendChild(x); return x; }
    var d = el('div', 'position:fixed;top:12px;right:12px;z-index:2147483647;background:#1f2328;color:#fff;padding:10px 12px;border-radius:10px;font:13px/1.35 system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.4);width:290px');
    var cab = el('div', 'display:flex;justify-content:space-between;align-items:center', '', d);
    el('b', '', '\uD83D\uDCE5 Escáner de fotos', cab);
    var cerrarX = el('span', 'cursor:pointer;padding:0 4px', '\u2715', cab);
    ui.n = el('div', 'font-size:22px;font-weight:700;margin:4px 0', '0', d);
    var editorAqui = !!window.EDITOR_SITIO || /github\.io$/.test(location.hostname);
    el('div', 'font-size:11px;opacity:.8;margin-bottom:8px', editorAqui
        ? 'Esto es el editor: pulsa el marcador en la página de Google Maps o TripAdvisor del restaurante.'
        : 'Sigue escuchando: en Maps abre la pestaña Carta (o Fotos), cambia de sección y usa "Bajar solo". Las fotos llegan solas al editor (🖼️ Fotos de internet).', d);
    var fila = el('div', 'display:flex;gap:6px', '', d);
    ui.b = el('button', 'flex:1;padding:6px;border:0;border-radius:6px;cursor:pointer;background:#fff;color:#1f2328', '\u21E3 Bajar solo', fila);
    var bk = el('button', 'flex:1;padding:6px;border:0;border-radius:6px;background:#16a34a;color:#fff;font-weight:700;cursor:pointer', 'Copiar', fila);
    ui.msg = el('div', 'font-size:11px;margin-top:6px;min-height:14px', '', d);
    ui.b.onclick = bajar;
    bk.onclick = copiar;
    cerrarX.onclick = function () { ui.cerrado = true; d.remove(); };
    function pintar() {
        if (!ui.n) return;
        if (modoExt && L.length && !ui.cerrado && !d.isConnected && document.body) document.body.appendChild(d); ui.n.textContent = L.length + ' fotos'; ui.b.textContent = bajando ? '■ Parar' : '⇣ Bajar solo'; }
    window.__fotosCarta = { mostrar: function () { ui.cerrado = false; if (!d.isConnected) document.body.appendChild(d); barrer(); pintar(); } };
    function montar() { arrancar(); if (!modoExt) document.body.appendChild(d); pintar(); }
    if (document.body) montar(); else document.addEventListener('DOMContentLoaded', montar);
}
escaner(true);
